<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Comment;
use App\Post;

class PostController extends Controller
{
   public function home()                                      //home.......................
   {  

          $posts= Post::orderBy('id','desc')->paginate(3);

  return view('pages.home', compact('posts'));

   	
   }


   public function home2()                                     //home2----------------------
   {
           $posts= Post::orderBy('id','desc')->paginate(3);

  return view('pages.home2', compact('posts'));

   
   }


  public function create()                                      //create-----------------------
    {
     $cats = Category::all();

	return view('pages.create',compact('cats'));

}

public function store( Request $request){                         //store-----------------------


$item= new Post;
$item->name= $request->name;
$item->content=$request->content;
$item->category_id=$request->category_id;

if($item->save()){
	return redirect('create')->with('success', 'Post has been added');

}

else{

	return redirect()->back()->with('error', 'Can not create record');

}

}

public function index(){                                                         //index----------------------------


$items= Post::orderBy('id','desc')->paginate(3);

return view('pages.index', compact('items'));

}



public function edit($id){                                                            //edit------------------------------


$items= Post::find($id);


return view('pages.edit', compact('items'));

}


public function update( Request $request){                                         //update--------------------------------


$item= Post::find($request->id);
$item->name= $request->name;
$item->content= $request->content;

if($item->save()){
  return redirect('/index')->with('success', 'Post has been Updated');

}

else{

  return redirect()->back()->with('error', 'Can not update record');

}

}


public function delete(Request $request){                                         //delete-------------------------------------


$item= Post::find($request->id);


if($item->delete()){
  return redirect('/index')->with('success', 'Post has been deleted');

}

}


public function view($id){                                                        //view individual post after login-------


$post= Post::find($id);
return view('pages.show')->withPost($post);

}

public function view2($id){                                                      //view individual post without login-------


$post= Post::find($id);
return view('pages.show2')->withPost($post);

}

public function storecomment( Request $request){

$item= new Comment;

$item->name= $request->name;
$item->post_id= $request->post_id;
$item->comment= $request->comment;

if($item->save()){
    return redirect('/index')->with('success', 'Comment has been added');

}

else{

    return redirect()->back()->with('error', 'Can not create record');

}

}



public function show_posts($id)
{

  $cats=Category::find($id);
  return view('pages.show_posts',compact('cats'));

}

public function show_posts2($id)
{

  $cats=Category::find($id);
  return view('pages.show_posts2',compact('cats'));

}

public function profile()
{

  return view('pages.profile');
}

}  //End of Controller
