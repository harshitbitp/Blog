<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PostController@home');     //HOME PAGE---------------------
Route::get('/about', function(){            //ABOUT PAGE--------------------
	return view('pages.about');
});

Route::get('/show2/{id}','PostController@view2');   //show individual posts to non-registered members
Route::get('/show_posts2/{id}','PostController@show_posts2');    //all posts of a particular category FOR NON REGISTERD USER

//After Logging in:--
Route::get('/home2', 'PostController@home2')->middleware('auth'); //HOME PAGE AFTER LOGIN---------------
Route::get('/create', 'PostController@create')->middleware('auth');  //create new post...............
 Route::post('/store', 'PostController@store');   //store contents and other thoings of posts..............
 Route::get('/index', 'PostController@index')->middleware('auth');    //settings........................
 Route::get('/edit/{id}', 'PostController@edit')->middleware('auth'); //edit.........................
Route::post('/update', 'PostController@update');  //upate------------------
Route::post('/delete','PostController@delete');   //delete----------------

Route::get('/show/{id}','PostController@view');     //show individual posts to registered members
Route::post('comm','PostController@storecomment');
Route::get('/show_posts/{id}','PostController@show_posts'); //show all posts of a particular category
Route::get('/profile','PostController@profile');              //show details of individual profile
Auth::routes();
Route::get('/logout', 'Auth\LoginController@logout');    //LOGOUT



//Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');             //NOT USED
