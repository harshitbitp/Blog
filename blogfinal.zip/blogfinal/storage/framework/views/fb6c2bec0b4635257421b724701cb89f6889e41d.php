 

<?php $__env->startSection('content'); ?>


<h1><a href="<?php echo e(url('/show_posts2',$post->category->id)); ?>"><button><?php echo e($post->category->name); ?></button></a></h1>
 <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="post-heading">
            <h1><?php echo e($post->name); ?></h1>
            <span class="meta">Posted on:-

              <a href="#"><?php echo e(date('M j, Y h:ia',strtotime($post->created_at))); ?></a>
             </span>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Post Content -->
  <article>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <p><?php echo e($post->content); ?></p>

       </div>
      </div>
    </div>
  </article>

  <hr>

  <center><h2 style="font-family: 'Kaushan Script';"> Comments</h2> </center>

<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<div class="card" style="width: 84rem;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($com->name); ?></h5>
    <p class="card-text">Posted At:<?php echo e(date('M j, Y h:ia',strtotime($com->created_at))); ?></p>
    <p class="card-text"><?php echo e($com->comment); ?></p>
  </div>
</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   <center><h4 style="color: black;font-family: 'Kaushan Script';">Add Comments</h4></center><br/>
      <form method="post" action="<?php echo e(url('comm')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="card" style="width: 84rem;"><input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" >
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Title"><span >Name:</span> </label>
            <input type="text" class="form-control"  rows="10"  name="name" >
          </div>
        </div>
        

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Title"><span>Email:</span> </label>
            <input type="text" class="form-control"  rows="10"  name="email" >
          </div>
        </div>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="comment"><span>Comment:</span> </label>
  <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" name="comment" rows="10"></textarea>
         </div>
          </div>
        </div>


        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Post Comment</button>
          </div>
        </div>
      </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>