<?php $__env->startSection('content'); ?>


    <div class="container">
      <h1>Your Profile</h1><br/>
    
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">  
                <div class="form-group">
					<h3>Name: <?php echo e(Auth::user()->name); ?></h3>
					<h3>Email:<?php echo e(Auth::user()->email); ?></h3>
          </div>
         </div>
       </div>
    
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>