 

<?php $__env->startSection('content'); ?>





<h3>List of Posts</h3>

<a href="<?php echo e(url('/create')); ?>" class="btn btn-md btn-success">NEW POST</a>

    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Body</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
      <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->content); ?></td>
        
        <td><a href="<?php echo e(url('/show',$item->id)); ?>" class="btn btn-primary">View</a>

<a href="<?php echo e(url('/edit',$item->id)); ?>" class="btn btn-warning">Edit</a>

        </td>
        <td>
          <form action="<?php echo e(url('/delete')); ?>" method="post">
<?php echo e(csrf_field()); ?>

            <input name="id" type="hidden" value="<?php echo e($item->id); ?>">

            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php echo e($items->links()); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>