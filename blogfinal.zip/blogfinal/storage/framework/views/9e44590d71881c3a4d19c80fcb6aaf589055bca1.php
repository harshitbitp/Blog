<?php $__env->startSection('content'); ?>

    <div class="container">
      <h2>Create New Post</h2><br/>
      <form method="post" action="<?php echo e(url('store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Name">Title</label>
            <input type="text" class="form-control" name="name">
          </div>
        </div>


        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">  
                <div class="form-group">
            <label for="exampleFormControlSelect1">Category</label>
             <select class="form-control" name="category_id" id="exampleFormControlSelect1">

              <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
          </div>
         </div>
       </div>
    
       <div class="form-group">
  <label for="exampleFormControlTextarea1">Content</label>
  <textarea class="form-control rounded-0" id="exampleFormControlTextarea1" name="content" rows="10"></textarea>
</div>

        
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <script type="text/javascript">  
        $('#datepicker').datepicker({ 
            autoclose: true,   
            format: 'dd-mm-yyyy'  
         });  
    </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>