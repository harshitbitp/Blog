


 @extends('layouts.afterLogin')

@section('content')


<h3>List of Posts</h3>

<a href="{{url('/create')}}" class="btn btn-md btn-success">NEW POST</a>

    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Body</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      
      @foreach($items as $item)
     
      <tr>
        <td>{{$item->id}}</td>
        <td>{{$item->name}}</td>
        <td>{{$item->content}}</td>
        
        <td><a href="{{url('/show',$item->id)}}" class="btn btn-primary">View</a>

<a href="{{url('/edit',$item->id)}}" class="btn btn-warning">Edit</a>

        </td>
        <td>
          <form action="{{url('/delete')}}" method="post">
{{csrf_field()}}
            <input name="id" type="hidden" value="{{$item->id}}">

            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
{{$items->links()}}




@endsection