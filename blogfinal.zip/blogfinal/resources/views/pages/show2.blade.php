

 @extends('layouts.app')

@section('content')


<h1><a href="{{url('/show_posts2',$post->category->id)}}"><button>{{$post->category->name}}</button></a></h1>
 <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="post-heading">
            <h1>{{ $post->name }}</h1>
            <span class="meta">Posted on:-

              <a href="#">{{date('M j, Y h:ia',strtotime($post->created_at))}}</a>
             </span>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Post Content -->
  <article>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <p>{{$post->content}}</p>

       </div>
      </div>
    </div>
  </article>

  <hr>

  <center><h2 style="font-family: 'Kaushan Script';"> Comments</h2> </center>

@foreach($post->comments as $com) 

<div class="card" style="width: 84rem;">
  <div class="card-body">
    <h5 class="card-title">{{$com->name}}</h5>
    <p class="card-text">Posted At:{{date('M j, Y h:ia',strtotime($com->created_at))}}</p>
    <p class="card-text">{{$com->comment}}</p>
  </div>
</div>
<hr>
@endforeach


   <center><h4 style="color: black;font-family: 'Kaushan Script';">Add Comments</h4></center><br/>
      <form method="post" action="{{url('comm')}}" enctype="multipart/form-data">
{{ csrf_field() }}

<div class="card" style="width: 84rem;"><input type="hidden" name="post_id" value="{{$post->id}}" >
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Title"><span >Name:</span> </label>
            <input type="text" class="form-control"  rows="10"  name="name" >
          </div>
        </div>
        

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Title"><span>Email:</span> </label>
            <input type="text" class="form-control"  rows="10"  name="email" >
          </div>
        </div>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="comment"><span>Comment:</span> </label>
  <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" name="comment" rows="10"></textarea>
         </div>
          </div>
        </div>


        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Post Comment</button>
          </div>
        </div>
      </form>

@endsection