
 @extends('layouts.afterLogin')

@section('content')


  <h2>Edit Post</h2><br/>
      <form method="post" action="{{url('/update')}}" enctype="multipart/form-data">
{{ csrf_field() }}

<input  type="hidden" value="{{$items->id}}" name="id">

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Title">Title:</label>
            <input type="text" class="form-control"  rows="10"  name="name" value="{{$items->name}}" >
          </div>
        </div>
        
       
             
          <div class="form-group">
  <label for="exampleFormControlTextarea1">Content</label>
  <textarea class="form-control rounded-0" id="exampleFormControlTextarea1" name="content" rows="10">
    {{$items->content}}
  </textarea>
</div>



        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Update</button>
          </div>
        </div>
      
      </form>

@endsection
