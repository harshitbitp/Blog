@extends('layouts.afterLogin')
@section('content')

    <div class="container">
      <h2>Create New Post</h2><br/>
      <form method="post" action="{{url('store')}}" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Name">Title</label>
            <input type="text" class="form-control" name="name">
          </div>
        </div>


        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">  
                <div class="form-group">
            <label for="exampleFormControlSelect1">Category</label>
             <select class="form-control" name="category_id" id="exampleFormControlSelect1">

              @foreach($cats as $cat)

            <option value="{{$cat->id}}">{{$cat->name}}</option>
                @endforeach
             </select>
          </div>
         </div>
       </div>
    
       <div class="form-group">
  <label for="exampleFormControlTextarea1">Content</label>
  <textarea class="form-control rounded-0" id="exampleFormControlTextarea1" name="content" rows="10"></textarea>
</div>

        
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="margin-top:60px">
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <script type="text/javascript">  
        $('#datepicker').datepicker({ 
            autoclose: true,   
            format: 'dd-mm-yyyy'  
         });  
    </script>
  @endsection