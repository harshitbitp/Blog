@extends('layouts.afterLogin')
@section('content')


    <div class="container">
      <h1>Your Profile</h1><br/>
    
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">  
                <div class="form-group">
					<h3>Name: {{Auth::user()->name}}</h3>
					<h3>Email:{{Auth::user()->email}}</h3>
          </div>
         </div>
       </div>
    
    </div>
    @endsection