@extends('layouts.app')
@section('content')


                                     
   <div class="container">
   
    <div class="row" >
      <div class="col-md-8">
        @foreach($posts as $post)
        <div class="post">
          <h3>{{$post->name}}</h3>
          <p>{{ substr($post->content,0,300)}}{{ strlen($post->content)>300 ? "..." : ""}}</p>
       <a href="{{url('/show2',$post->id)}}"  class="btn btn-primary">Read More</a>
        </div>
        <hr>
        @endforeach
      </div>
      </div>
</div>
@endsection